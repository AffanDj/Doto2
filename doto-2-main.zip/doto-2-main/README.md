# Doto-2
This my first project using HTML &amp; CSS. The website was inspired by multiplayer online battle arena (MOBA) called Dota 2. In this project I learned to design and run the website properly.
